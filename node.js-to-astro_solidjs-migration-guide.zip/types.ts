export enum Feature {
    PROJECT_STRUCTURE = 'Project Structure Analysis',
    API_ENDPOINTS = 'API Endpoints',
    DATABASE_ACCESS = 'Database Access',
    AUTHENTICATION = 'Authentication',
    STATIC_FILES = 'Serving Static Files',
    SSR_PAGES = 'Server-Side Rendered Pages',
    MIDDLEWARE = 'Middleware',
}

export enum ArchitecturalLayer {
    BACKEND_DATA = 'Backend & Data',
    FRONTEND_UI = 'Frontend & UI',
    AUTH_SECURITY = 'Authentication & Security',
    REQUEST_HANDLING = 'Request Handling & Rendering',
}

export interface FeatureInfo {
    id: Feature;
    label: string;
    description: string;
    icon: string;
}