
import React from 'react';

interface ErrorMessageProps {
    message: string;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message }) => {
    // A more prominent style for actual errors, and a subdued one for disclaimers/warnings
    const isError = message.toLowerCase().startsWith('error:') || message.toLowerCase().startsWith('failed');
    const messageClass = isError ? 'error-message error' : 'error-message warning';

    return (
        <div className={messageClass} role="alert">
            <strong className="font-bold">{isError ? 'Error: ' : 'Disclaimer: '}</strong>
            <span className="block sm:inline">{message.replace(/^(error|failed to generate script|disclaimer): /i, '')}</span>
        </div>
    );
};

export default ErrorMessage;
