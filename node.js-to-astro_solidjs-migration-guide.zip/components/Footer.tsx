import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="site-footer">
            <div className="footer-content">
                <div className="footer-item">
                    <span>Developed By</span>
                    <p>eLgatoAi</p>
                </div>
                <div className="footer-item">
                    <span>Powered By</span>
                    <p>Gemini AI</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;