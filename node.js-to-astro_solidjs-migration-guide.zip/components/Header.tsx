
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="py-6 bg-gray-900/70 backdrop-blur-sm sticky top-0 z-10 border-b border-gray-800">
            <div className="container mx-auto px-4 max-w-5xl text-center">
                <h1 className="text-3xl sm:text-4xl font-bold text-white">
                    Node.js to Astro/SolidJS Migration Guide
                </h1>
                <p className="mt-2 text-lg text-cyan-400">
                    Your AI-powered architectural assistant.
                p>
            </div>
        </header>
    );
};

export default Header;
