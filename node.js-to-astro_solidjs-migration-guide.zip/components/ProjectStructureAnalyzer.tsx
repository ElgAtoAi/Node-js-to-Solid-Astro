import React, { useState } from 'react';

interface ProjectStructureAnalyzerProps {
    onAnalyze: (structure: string) => void;
}

const ProjectStructureAnalyzer: React.FC<ProjectStructureAnalyzerProps> = ({ onAnalyze }) => {
    const [structure, setStructure] = useState('');
    const placeholder = `Example:
my-node-app/
├── src/
│   ├── components/
│   │   └── button.js
│   ├── routes/
│   │   ├── api/
│   │   │   └── users.js
│   │   └── views.js
│   ├── models/
│   │   └── user.js
│   └── index.js
├── public/
│   └── styles.css
└── package.json`;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (structure.trim()) {
            onAnalyze(structure);
        }
    };

    return (
        <div className="analyzer-container">
            <header className="guide-header">
                <h1>Analyze Your Project Structure</h1>
                <p>Paste your project's directory structure to get a detailed migration plan and an optional automation script.</p>
            </header>
            
            <form onSubmit={handleSubmit} className="analyzer-form">
                <p className="guide-p">
                    You can generate the structure using commands like <code className="guide-inline-code">tree -d</code> or <code className="guide-inline-code">ls -R</code>.
                </p>
                <textarea
                    value={structure}
                    onChange={(e) => setStructure(e.target.value)}
                    placeholder={placeholder}
                    className="analyzer-textarea"
                    aria-label="Project structure input"
                    rows={15}
                />
                <button
                    type="submit"
                    disabled={!structure.trim()}
                    className="action-button"
                >
                    Generate Migration Plan
                </button>
            </form>
        </div>
    );
};

export default ProjectStructureAnalyzer;