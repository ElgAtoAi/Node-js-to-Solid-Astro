
import React, { useState } from 'react';

interface ProjectStructureAnalyzerProps {
    onAnalyze: (structure: string) => void;
}

const ProjectStructureAnalyzer: React.FC<ProjectStructureAnalyzerProps> = ({ onAnalyze }) => {
    const [structure, setStructure] = useState('');
    const placeholder = `Example:
my-node-app/
├── src/
│   ├── components/
│   │   └── button.js
│   ├── routes/
│   │   ├── api/
│   │   │   └── users.js
│   │   └── views.js
│   ├── models/
│   │   └── user.js
│   └── index.js
├── public/
│   └── styles.css
└── package.json`;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (structure.trim()) {
            onAnalyze(structure);
        }
    };

    return (
        <div className="bg-gray-800/50 p-6 sm:p-8 rounded-lg border border-gray-700 animate-fade-in">
            <h2 className="text-2xl font-bold text-white mb-4">
                Analyze Your Project Structure
            </h2>
            <p className="text-gray-400 mb-6">
                Paste your Node.js project's directory structure below to get a detailed migration plan and an optional automation script. You can generate the structure using commands like <code className="bg-gray-700 text-cyan-300 rounded-md px-1.5 py-0.5 text-sm font-mono">tree -d</code> or <code className="bg-gray-700 text-cyan-300 rounded-md px-1.5 py-0.5 text-sm font-mono">ls -R</code>.
            </p>
            <form onSubmit={handleSubmit}>
                <textarea
                    value={structure}
                    onChange={(e) => setStructure(e.target.value)}
                    placeholder={placeholder}
                    className="w-full h-72 p-4 bg-gray-900 border border-gray-600 rounded-lg text-gray-300 font-mono text-sm focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
                    aria-label="Project structure input"
                />
                <button
                    type="submit"
                    disabled={!structure.trim()}
                    className="mt-6 w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all"
                >
                    Generate Migration Plan
                </button>
            </form>
        </div>
    );
};

export default ProjectStructureAnalyzer;
