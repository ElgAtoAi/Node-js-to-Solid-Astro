import React from 'react';

interface SiteHeaderProps {
  onLogoClick: () => void;
}

const SiteHeader: React.FC<SiteHeaderProps> = ({ onLogoClick }) => {
    return (
        <header className="site-header">
            <button onClick={onLogoClick} className="logo-button" aria-label="Go to homepage">
                <img src="/eLgAtoAi_logo.jpg" alt="eLgatoAi Logo" className="logo-image" width="120" height="30" />
            </button>
            <h1 className="site-title">AI Migration Assistant</h1>
        </header>
    );
};

export default SiteHeader;