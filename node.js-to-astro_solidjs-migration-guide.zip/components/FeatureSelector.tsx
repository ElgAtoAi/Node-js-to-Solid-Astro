
import React from 'react';
import { Feature } from '../types';
import { FEATURES } from '../constants';

interface FeatureSelectorProps {
    onSelectFeature: (feature: Feature) => void;
    isLoading: boolean;
}

const FeatureSelector: React.FC<FeatureSelectorProps> = ({ onSelectFeature, isLoading }) => {
    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURES.map((featureInfo) => (
                <button
                    key={featureInfo.id}
                    onClick={() => onSelectFeature(featureInfo.id)}
                    disabled={isLoading}
                    className="group bg-gray-800 p-6 rounded-lg border border-gray-700 hover:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all duration-300 transform hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                    <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">{featureInfo.icon}</div>
                        <div className="text-left">
                            <h3 className="text-lg font-semibold text-white group-hover:text-cyan-400 transition-colors">
                                {featureInfo.label}
                            </h3>
                            <p className="text-sm text-gray-400 mt-1">{featureInfo.description}</p>
                        </div>
                    </div>
                </button>
            ))}
        </div>
    );
};

export default FeatureSelector;
