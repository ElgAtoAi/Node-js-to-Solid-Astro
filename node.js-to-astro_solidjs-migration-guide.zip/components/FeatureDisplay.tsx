import React from 'react';
import { Feature } from '../types';
import { FEATURES } from '../constants';

interface FeatureDisplayProps {
    onFeatureSelect: (feature: Feature) => void;
}

const FeatureDisplay: React.FC<FeatureDisplayProps> = ({ onFeatureSelect }) => {
    return (
        <div className="feature-display-container">
            <header className="feature-list-header">
                <h2>Migration Blueprints</h2>
                <p>Select a feature to get a detailed, step-by-step migration guide.</p>
            </header>
            <ul className="feature-list">
                {FEATURES.map((feature) => (
                    <li key={feature.id}>
                        <button className="feature-item" onClick={() => onFeatureSelect(feature.id)}>
                            <span className="feature-icon">{feature.icon}</span>
                            <div className="feature-text">
                                <h3 className="feature-label">{feature.label}</h3>
                                <p className="feature-description">{feature.description}</p>
                            </div>
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default FeatureDisplay;