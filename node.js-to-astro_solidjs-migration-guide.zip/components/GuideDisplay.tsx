
import React, { useState, FC, useMemo } from 'react';
import { Feature } from '../types';
import Loader from './Loader';
import ErrorMessage from './ErrorMessage';

interface CodeBlockProps {
    code: string;
    language?: string;
}

const CodeBlock: FC<CodeBlockProps> = ({ code, language }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(code);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="bg-gray-800 rounded-lg my-4 relative">
            <div className="flex justify-between items-center px-4 py-2 bg-gray-700/50 rounded-t-lg">
                <span className="text-xs font-sans text-gray-400">{language || 'code'}</span>
                <button
                    onClick={handleCopy}
                    className="text-xs text-gray-300 hover:text-white flex items-center"
                    aria-label="Copy code to clipboard"
                >
                    {copied ? (
                        <>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            Copied!
                        </>
                    ) : (
                         <>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                            </svg>
                            Copy
                        </>
                    )}
                </button>
            </div>
            <pre className="p-4 text-sm overflow-x-auto">
                <code className={`language-${language}`}>{code.trim()}</code>
            </pre>
        </div>
    );
};


interface MarkdownTextProps {
  text: string;
}

const MarkdownText: FC<MarkdownTextProps> = ({ text }) => {
  const processLine = (line: string, index: number) => {
    if (line.startsWith('### ')) {
      return <h3 key={index} className="text-xl font-semibold text-white mt-6 mb-2">{line.substring(4)}</h3>;
    }
    if (line.startsWith('## ')) {
      return <h2 key={index} className="text-2xl font-bold text-cyan-400 border-b border-gray-700 pb-2 mt-8 mb-4">{line.substring(3)}</h2>;
    }
     if (line.startsWith('**##')) { // Handle bolded headers
      return <h2 key={index} className="text-2xl font-bold text-cyan-400 border-b border-gray-700 pb-2 mt-8 mb-4">{line.substring(5)}</h2>;
    }
    if (line.startsWith('- ') || line.startsWith('* ')) {
      const isTableHeader = /\|.*\|/.test(line);
      if(isTableHeader) return null; // Filter out table-like lines inside lists
      return <li key={index} className="ml-5 list-disc text-gray-300">{renderInlineFormatting(line.substring(2))}</li>;
    }
    if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
       // This is a simple table row renderer. A more robust solution might be needed for complex tables.
       const cells = line.trim().split('|').slice(1, -1);
       // Skip separator line
       if (cells.every(cell => cell.trim().replace(/-/g, '') === '')) {
           return null;
       }
       return (
         <tr key={index} className="border-b border-gray-700">
           {cells.map((cell, cellIndex) => (
             <td key={cellIndex} className="p-2 text-gray-300">{renderInlineFormatting(cell.trim())}</td>
           ))}
         </tr>
       );
    }
    if (line.trim() === '') {
        return null; // Don't render empty paragraphs, use margin/padding on other elements
    }
    return <p key={index} className="my-4 text-gray-300 leading-relaxed">{renderInlineFormatting(line)}</p>;
  };
  
  const renderInlineFormatting = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*|\`.*?\`)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-bold text-white">{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return <code key={i} className="bg-gray-700 text-cyan-300 rounded-md px-1.5 py-0.5 text-sm font-mono">{part.slice(1, -1)}</code>;
      }
      return part;
    });
  };

  const lines = text.split('\n');
  const elements = [];
  let isTable = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const isLineTable = line.trim().startsWith('|') && line.trim().endsWith('|');

    if (isLineTable && !isTable) {
        isTable = true;
        const headerCells = line.trim().split('|').slice(1, -1);
        elements.push(
            <table key={`table-${i}`} className="w-full text-left border-collapse my-4">
                <thead>
                    <tr className="border-b-2 border-cyan-500">
                        {headerCells.map((cell, cellIndex) => (
                            <th key={cellIndex} className="p-2 font-semibold text-white">{cell.trim()}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>{processLine(lines[i+2], i+2) /* Assumes separator line is next */}</tbody>
            </table>
        );
        i = i + 2; // Skip header row and separator
    } else if (isLineTable && isTable) {
        // This logic assumes tables are contiguous. Find the parent table and append.
        const table = elements[elements.length - 1];
        if(table && table.type === 'table') {
            table.props.children[1].props.children.push(processLine(line, i));
        }
    } 
    else {
        isTable = false;
        elements.push(processLine(line, i));
    }
  }

  return <>{elements}</>;
};


interface GuideDisplayProps {
    content: string;
    feature: Feature;
    onGenerateScript: () => void;
    script: string | null;
    isGeneratingScript: boolean;
}

const GuideDisplay: FC<GuideDisplayProps> = ({ content, feature, onGenerateScript, script, isGeneratingScript }) => {
    const renderedContent = useMemo(() => {
        const parts = content.split(/(\`\`\`[a-z]*\n[\s\S]*?\n\`\`\`)/g).filter(Boolean);

        return parts.map((part, index) => {
            if (part.startsWith('```')) {
                const match = part.match(/\`\`\`([a-z]*)\n/);
                const lang = match ? match[1] : '';
                const code = part.replace(/\`\`\`[a-z]*\n/, '').replace(/\n\`\`\`$/, '');
                return <CodeBlock key={index} code={code} language={lang} />;
            }
            return <MarkdownText key={index} text={part} />;
        });
    }, [content]);

    return (
        <div className="animate-fade-in">
            <article className="bg-gray-800/50 p-6 sm:p-8 rounded-lg border border-gray-700">
                <h1 className="text-3xl font-bold text-white mb-6">
                    Migration Guide: <span className="text-cyan-400">{feature}</span>
                </h1>
                {renderedContent}
            </article>

            {feature === Feature.PROJECT_STRUCTURE && (
                <div className="mt-8 bg-gray-800/50 p-6 sm:p-8 rounded-lg border border-gray-700">
                    <h2 className="text-2xl font-bold text-white mb-4">Automation Assistant</h2>
                    <p className="text-gray-400 mb-6">
                        Turn this migration plan into action. Generate a Node.js script to automate project setup and file migration.
                    </p>
                    <button
                        onClick={onGenerateScript}
                        disabled={isGeneratingScript}
                        className="w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all"
                    >
                        {isGeneratingScript ? 'Generating Script...' : 'Generate Automation Script'}
                    </button>

                    {isGeneratingScript && <Loader message="Building your custom migration script with Gemini..." />}
                    
                    {script && (
                        <div className="mt-8">
                            <ErrorMessage message="Disclaimer: This generated script is a powerful starting point, but not a replacement for manual review. Always back up your project before running automation. Review the script carefully to understand its actions." />
                            <CodeBlock code={script} language="javascript" />
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default GuideDisplay;
