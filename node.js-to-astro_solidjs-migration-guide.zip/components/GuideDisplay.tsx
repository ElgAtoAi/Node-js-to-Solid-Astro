
import React, { useState, FC, useMemo } from 'react';
import { Feature, FeatureInfo } from '../types';
import { FEATURE_MAP } from '../constants';
import Loader from './Loader';
import ErrorMessage from './ErrorMessage';

interface CodeBlockProps {
    code: string;
    language?: string;
}

const CodeBlock: FC<CodeBlockProps> = ({ code, language }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(code);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="code-block-wrapper">
            <div className="code-block-header">
                <span className="code-block-language">{language || 'code'}</span>
                <button onClick={handleCopy} className="code-block-copy-button" aria-label="Copy code to clipboard">
                    {copied ? "Copied!" : "Copy"}
                </button>
            </div>
            <pre className="code-block-pre">
                <code className={`language-${language}`}>{code.trim()}</code>
            </pre>
        </div>
    );
};

interface MarkdownTextProps {
  text: string;
}

const MarkdownText: FC<MarkdownTextProps> = ({ text }) => {
  const processLine = (line: string, index: number): React.ReactElement | null => {
    if (line.startsWith('### ')) {
      return <h3 key={index} className="guide-h3">{line.substring(4)}</h3>;
    }
    if (line.startsWith('## ')) {
      return <h2 key={index} className="guide-h2">{line.substring(3)}</h2>;
    }
     if (line.startsWith('**##')) { // Handle bolded headers
      return <h2 key={index} className="guide-h2">{line.substring(5)}</h2>;
    }
    if (line.startsWith('- ') || line.startsWith('* ')) {
       return <li key={index}>{renderInlineFormatting(line.substring(2))}</li>;
    }
    if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
       const cells = line.trim().split('|').slice(1, -1);
       if (cells.every(cell => cell.trim().replace(/-/g, '') === '')) return null;
       return (
         <tr key={index}>
           {cells.map((cell, cellIndex) => (
             <td key={cellIndex}>{renderInlineFormatting(cell.trim())}</td>
           ))}
         </tr>
       );
    }
    if (line.trim() === '') {
        return null;
    }
    return <p key={index} className="guide-p">{renderInlineFormatting(line)}</p>;
  };
  
  const renderInlineFormatting = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*|\`.*?\`)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i}>{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return <code key={i} className="guide-inline-code">{part.slice(1, -1)}</code>;
      }
      return part;
    });
  };

  const lines = text.split('\n');
  const elements: (React.ReactElement | null)[] = [];
  let currentListItems: React.ReactElement[] = [];
  let currentTable: { head: React.ReactElement | null; body: React.ReactElement[] } | null = null;

  lines.forEach((line, i) => {
    const isListItem = line.startsWith('- ') || line.startsWith('* ');
    const isTableLine = line.trim().startsWith('|') && line.trim().endsWith('|');

    if (!isListItem && currentListItems.length > 0) {
        elements.push(<ul key={`list-${i}`} className="guide-ul">{currentListItems}</ul>);
        currentListItems = [];
    }
    if(!isTableLine && currentTable){
        elements.push(
            <table key={`table-${i}`} className="guide-table">
                {currentTable.head && <thead>{currentTable.head}</thead>}
                <tbody>{currentTable.body}</tbody>
            </table>
        );
        currentTable = null;
    }

    if (isListItem) {
        const li = processLine(line, i);
        if (li) currentListItems.push(li);
    } else if (isTableLine) {
        if (!currentTable) {
            currentTable = { head: null, body: [] };
            const headerCells = line.trim().split('|').slice(1, -1);
            currentTable.head = <tr key={`thr-${i}`}>{headerCells.map((cell, cellIndex) => <th key={cellIndex}>{cell.trim()}</th>)}</tr>;
            // Skip the separator line in the next iteration
            if (lines[i + 1] && lines[i+1].includes('---')) {
                // This is a simple check, might need to be more robust
            }
        } else if (!line.includes('---')) {
             const tr = processLine(line, i);
             if (tr) currentTable.body.push(tr);
        }
    } else {
        elements.push(processLine(line, i));
    }
  });

  if (currentListItems.length > 0) {
      elements.push(<ul key="list-end" className="guide-ul">{currentListItems}</ul>);
  }
  if (currentTable) {
       elements.push(
            <table key="table-end" className="guide-table">
                {currentTable.head && <thead>{currentTable.head}</thead>}
                <tbody>{currentTable.body}</tbody>
            </table>
        );
  }

  return <>{elements.filter(Boolean)}</>;
};

interface GuideDisplayProps {
    content: string;
    feature: Feature;
    onGenerateScript: () => void;
    script: string | null;
    isGeneratingScript: boolean;
}

const GuideDisplay: FC<GuideDisplayProps> = ({ content, feature, onGenerateScript, script, isGeneratingScript }) => {
    const featureInfo = FEATURE_MAP.get(feature);

    const renderedContent = useMemo(() => {
        const parts = content.split(/(\`\`\`[a-z]*\n[\s\S]*?\n\`\`\`)/g).filter(Boolean);

        return parts.map((part, index) => {
            if (part.startsWith('```')) {
                const match = part.match(/\`\`\`([a-z]*)\n/);
                const lang = match ? match[1] : '';
                const code = part.replace(/\`\`\`[a-z]*\n/, '').replace(/\n\`\`\`$/, '');
                return <CodeBlock key={index} code={code} language={lang} />;
            }
            return <MarkdownText key={index} text={part} />;
        });
    }, [content]);

    return (
        <article className="guide-container">
            <header className="guide-header">
                <h1>{featureInfo?.label || 'Migration Guide'}</h1>
                <p>{featureInfo?.description}</p>
            </header>
            
            <div className="guide-content">
                {renderedContent}
            </div>

            {feature === Feature.PROJECT_STRUCTURE && (
                <div className="automation-section">
                    <h2 className="guide-h2">Automation Assistant</h2>
                    <p className="guide-p">
                        Turn this migration plan into action. Generate a Node.js script to automate project setup and file migration.
                    </p>
                    <button
                        onClick={onGenerateScript}
                        disabled={isGeneratingScript}
                        className="action-button"
                    >
                        {isGeneratingScript ? 'Generating Script...' : 'Generate Automation Script'}
                    </button>

                    {isGeneratingScript && <Loader message="Building your custom migration script with Gemini..." />}
                    
                    {script && (
                        <div className="script-display">
                            <ErrorMessage message="Disclaimer: This generated script is a powerful starting point, but not a replacement for manual review. Always back up your project before running automation. Review the script carefully to understand its actions." />
                            <CodeBlock code={script} language="javascript" />
                        </div>
                    )}
                </div>
            )}
        </article>
    );
};

export default GuideDisplay;
