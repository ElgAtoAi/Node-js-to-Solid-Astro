
import React, { useState } from 'react';
import { Feature, ArchitecturalLayer } from '../types';
import { ONBOARDING_QUESTION_DATA, LAYER_TO_FEATURE_MAP, FEATURE_MAP } from '../constants';

interface OnboardingWizardProps {
    onFeatureSelect: (feature: Feature) => void;
    onBack: () => void;
}

const OnboardingWizard: React.FC<OnboardingWizardProps> = ({ onFeatureSelect, onBack }) => {
    const [step, setStep] = useState<1 | 2>(1);
    const [selectedLayer, setSelectedLayer] = useState<ArchitecturalLayer | null>(null);

    const handleLayerSelect = (layer: ArchitecturalLayer) => {
        setSelectedLayer(layer);
        setStep(2);
    };

    const handleBackToStep1 = () => {
        setSelectedLayer(null);
        setStep(1);
    }
    
    const renderStep1 = () => (
        <div className="animate-fade-in">
            <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-white">Let's narrow it down.</h2>
                <p className="text-gray-400 mt-2">First, which architectural layer are you focused on?</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {ONBOARDING_QUESTION_DATA.map(({ layer, description, icon }) => (
                    <button
                        key={layer}
                        onClick={() => handleLayerSelect(layer)}
                        className="group bg-gray-800 p-6 rounded-lg border border-gray-700 hover:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all duration-300 transform hover:-translate-y-1"
                    >
                         <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0">{icon}</div>
                            <div className="text-left">
                                <h3 className="text-lg font-semibold text-white group-hover:text-cyan-400 transition-colors">
                                    {layer}
                                </h3>
                                <p className="text-sm text-gray-400 mt-1">{description}</p>
                            </div>
                        </div>
                    </button>
                ))}
            </div>
             <div className="text-center mt-8">
                <button
                    onClick={onBack}
                    className="text-sm font-semibold text-gray-400 hover:text-cyan-400 transition-colors"
                >
                    Or, go back to start
                </button>
            </div>
        </div>
    );

    const renderStep2 = () => {
        if (!selectedLayer) return null;
        const features = LAYER_TO_FEATURE_MAP[selectedLayer];
        
        return (
            <div className="animate-fade-in">
                <div className="text-center mb-8">
                    <h2 className="text-2xl font-bold text-white">Great. Now, what's the goal?</h2>
                    <p className="text-gray-400 mt-2">What specific task do you need to accomplish within <span className="text-cyan-400 font-semibold">{selectedLayer}</span>?</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {features.map(featureId => {
                        const featureInfo = FEATURE_MAP.get(featureId);
                        if (!featureInfo) return null;
                        return (
                            <button
                                key={featureInfo.id}
                                onClick={() => onFeatureSelect(featureInfo.id)}
                                className="group bg-gray-800 p-6 rounded-lg border border-gray-700 hover:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all duration-300 transform hover:-translate-y-1 text-left h-full flex flex-col"
                            >
                               <div className="flex items-start space-x-4">
                                    <div className="flex-shrink-0">{featureInfo.icon}</div>
                                    <div className="flex-1">
                                        <h3 className="text-lg font-semibold text-white group-hover:text-cyan-400 transition-colors">
                                            {featureInfo.label}
                                        </h3>
                                        <p className="text-sm text-gray-400 mt-1">{featureInfo.description}</p>
                                    </div>
                                </div>
                            </button>
                        );
                    })}
                </div>
                 <div className="text-center mt-8">
                    <button
                        onClick={handleBackToStep1}
                        className="text-sm font-semibold text-gray-400 hover:text-cyan-400 transition-colors flex items-center mx-auto group"
                    >
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 transform group-hover:-translate-x-1 transition-transform" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                        Back to layers
                    </button>
                </div>
            </div>
        )
    };
    
    return step === 1 ? renderStep1() : renderStep2();
};

export default OnboardingWizard;
