
import React, { useState } from 'react';
import { Feature, ArchitecturalLayer } from '../types';
import { ONBOARDING_QUESTION_DATA, LAYER_TO_FEATURE_MAP, FEATURE_MAP } from '../constants';

interface OnboardingWizardProps {
    onFeatureSelect: (feature: Feature) => void;
    onBack: () => void;
}

// A simple card component for the wizard options
const WizardCard = ({ title, description, onClick }: { title: string; description: string; onClick: () => void; }) => (
    <button onClick={onClick} className="wizard-card">
        <h3>{title}</h3>
        <p>{description}</p>
    </button>
);

const OnboardingWizard: React.FC<OnboardingWizardProps> = ({ onFeatureSelect, onBack }) => {
    const [step, setStep] = useState<1 | 2>(1);
    const [selectedLayer, setSelectedLayer] = useState<ArchitecturalLayer | null>(null);

    const handleLayerSelect = (layer: ArchitecturalLayer) => {
        setSelectedLayer(layer);
        setStep(2);
    };

    const handleBackToStep1 = () => {
        setSelectedLayer(null);
        setStep(1);
    }
    
    const renderStep1 = () => (
        <div className="wizard-step">
            <header className="guide-header">
                <h1>Let's narrow it down.</h1>
                <p>First, which architectural layer are you focused on?</p>
            </header>
            <div className="wizard-grid">
                {ONBOARDING_QUESTION_DATA.map(({ layer, description }) => (
                     <WizardCard 
                        key={layer}
                        title={layer}
                        description={description}
                        onClick={() => handleLayerSelect(layer)}
                     />
                ))}
            </div>
        </div>
    );

    const renderStep2 = () => {
        if (!selectedLayer) return null;
        const features = LAYER_TO_FEATURE_MAP[selectedLayer];
        
        return (
            <div className="wizard-step">
                <header className="guide-header">
                    <h1>Great. Now, what's the goal?</h1>
                    <p>What specific task do you need to accomplish within <span className="highlight">{selectedLayer}</span>?</p>
                </header>
                <div className="wizard-grid">
                    {features.map(featureId => {
                        const featureInfo = FEATURE_MAP.get(featureId);
                        if (!featureInfo) return null;
                        return (
                           <WizardCard
                                key={featureInfo.id}
                                title={featureInfo.label}
                                description={featureInfo.description}
                                onClick={() => onFeatureSelect(featureInfo.id)}
                           />
                        );
                    })}
                </div>
                <div style={{ textAlign: 'center', marginTop: '4rem' }}>
                    <button onClick={handleBackToStep1} className="back-button">
                        &larr; Back to layers
                    </button>
                </div>
            </div>
        )
    };
    
    return step === 1 ? renderStep1() : renderStep2();
};

export default OnboardingWizard;
