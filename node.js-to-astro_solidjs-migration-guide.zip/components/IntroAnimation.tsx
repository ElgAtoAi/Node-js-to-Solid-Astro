import React, { useEffect } from 'react';

interface IntroAnimationProps {
  onAnimationComplete: () => void;
}

const IntroAnimation: React.FC<IntroAnimationProps> = ({ onAnimationComplete }) => {
  useEffect(() => {
    // The total animation sequence is complex, this timeout ensures the user sees the full effect
    // before the main app loads. The duration is set to align with the CSS animations.
    const animationTimer = setTimeout(() => {
      onAnimationComplete();
    }, 4000); // 4 seconds to allow the animation to play out

    return () => clearTimeout(animationTimer);
  }, [onAnimationComplete]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      {/* The button and its children are structured to create the glitch effect from the template */}
      <button className="cybr-btn text-xl">
        Initializing Migration Assistant<span aria-hidden>_</span>
        <span aria-hidden className="cybr-btn__glitch">Initializing...</span>
        {/* The tag is a decorative element from the original design */}
        <span aria-hidden className="cybr-btn__tag">R25</span>
      </button>
    </div>
  );
};

export default IntroAnimation;
