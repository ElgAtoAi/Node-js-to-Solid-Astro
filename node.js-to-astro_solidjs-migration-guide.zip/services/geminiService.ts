
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Feature } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const callGeminiStream = async (prompt: string, systemInstruction: string) => {
     try {
        return ai.models.generateContentStream({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                temperature: 0.5,
            }
        });
    } catch (error) {
        console.error("Error generating content from Gemini:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate content: ${error.message}`);
        }
        throw new Error("An unknown error occurred while contacting the Gemini API.");
    }
};

export const generateMigrationGuide = async (feature: Feature): Promise<string> => {
    const systemInstruction = `You are a world-class software architect with deep expertise in Node.js (specifically Express), Astro, and SolidJS. Your goal is to provide clear, concise, and developer-friendly migration guides.

You must format your response using markdown syntax. Use headings, lists, and code blocks to structure the guide.
- Use '##' for main sections (e.g., '## Node.js / Express Approach' and '## Astro / SolidJS Hybrid Approach').
- Use '###' for sub-headings.
- Use fenced code blocks with language identifiers (e.g., \`\`\`javascript, \`\`\`typescript, \`\`\`astro, \`\`\`tsx).
- Use **bold** for emphasis on key terms.
- Use \`inline code\` for variable names, file names, and commands.`;

    const prompt = `
Generate a migration guide for the feature: **${feature}**.

The guide must contain two primary sections:
1.  **Node.js / Express Approach**: Briefly explain how this feature is typically implemented in a standard Node.js Express application. Provide a concise and illustrative code snippet.
2.  **Astro / SolidJS Hybrid Approach**: Provide a detailed, step-by-step explanation of how to achieve the same functionality in an Astro project. 
    - Explain the Astro-specific concepts being used (e.g., API routes, middleware, islands architecture).
    - If the feature involves UI, show how to create an interactive SolidJS component and integrate it as an Astro island using the \`client:load\` directive.
    - Provide clear, complete, and practical code examples for Astro components (\`.astro\`), API routes (\`.ts\`), and SolidJS components (\`.tsx\`).

Ensure the explanation is easy to follow for a developer who is familiar with Node.js but new to Astro and SolidJS.
`;
    // For single feature guides, streaming isn't strictly necessary as they are fast.
    // We can aggregate the stream here for simplicity in the calling component.
     const stream = await callGeminiStream(prompt, systemInstruction);
     let text = '';
     for await (const chunk of stream) {
         text += chunk.text;
     }
     return text;
};

export const generateProjectMigrationPlan = (projectStructure: string) => {
    const systemInstruction = `You are a world-class software architect specializing in cloud-native migrations from Node.js to Jamstack architectures like Astro. Your task is to analyze a user-provided directory structure and create a comprehensive, step-by-step migration plan to a modern Astro/SolidJS project, ready for Cloudflare deployment.

Your response MUST be formatted in markdown. Follow this structure precisely. Do not add conversational filler.

**Guide Structure:**

**## 0. ⚠️ Important: Back Up Your Project!**
- Start with a strong warning. Advise the user to make a complete backup of their original project in a separate directory or commit all changes to Git before starting the migration process. Emphasize that this is for safety.

**## 1. Initial Project Setup**
- Explain that the first step is to create a brand new Astro project in a **separate directory** to prevent conflicts.
- Provide the single command block to create the project, navigate into it, and state the recommended prompts answers (Basics template, TypeScript, install dependencies, git).

**## 2. Project Analysis**
- Briefly acknowledge the provided structure and identify the likely purpose of key directories (e.g., "The 'src/routes' directory appears to contain your API definitions.").

**## 3. Recommended Astro Project Structure**
- Present a new, recommended file structure for the Astro project in a single, clear, tree-like code block. Show how original files map to new locations (e.g., \`Button.tsx (from 'src/components/button.js')\`).

**## 4. File Migration Guide**
- Provide a markdown table mapping old files/folders to their new locations. Columns: | Original Path | New Astro Path | Notes |

**## 5. Cloudflare Deployment Setup**
- Use subheadings for this section.
- **### Astro & Wrangler Configuration**: Provide complete, copy-pasteable code blocks for \`astro.config.mjs\` (configured for Cloudflare) and \`wrangler.toml\`. Use placeholders like \`<YOUR_PROJECT_NAME>\`.
- **### Deployment Commands**: List the terminal commands to build and deploy to Cloudflare.

**## 6. Next Steps & Recommendations**
- Briefly list 3-5 key actions the developer should take next, such as converting component logic, handling environment variables, and testing API routes.`;

    const prompt = `Analyze the following Node.js project structure and generate a detailed migration and deployment plan for Astro/SolidJS on Cloudflare.

**Project Structure:**
\`\`\`text
${projectStructure}
\`\`\`
`;
    return callGeminiStream(prompt, systemInstruction);
};

export const generateMigrationScript = (projectStructure: string) => {
    const systemInstruction = `You are an expert developer specializing in creating command-line interface (CLI) tools with Node.js. Your task is to generate a complete, runnable Node.js script that automates the migration of a project from a legacy structure to a modern Astro/SolidJS setup. The user has provided their project's file structure. Your generated script should be tailored to that specific structure.

**Script Requirements:**

1.  **Language & Style:**
    - Use modern JavaScript (ESM: \`import\`/\`export\`).
    - The script must be a single file, executable with \`node your-script-name.js\`.
    - It must use \`inquirer\` for user prompts, \`chalk\` for colored console output, and \`fs-extra\` for robust file system operations.
    - At the top of the script, in a comment, explain the prerequisites: \`npm install inquirer chalk fs-extra\`.
    - The code must be well-commented, clean, and easy to understand.

2.  **Functionality:**
    - **User Input:** Prompt the user for the new target directory name, Cloudflare project name, and Zone ID using \`inquirer\`. The source directory is assumed to be the current directory or a known path.
    - **Project Scaffolding:** Execute shell commands (\`child_process.execSync\`) to create the new Astro project, run \`npm create astro@latest\`, and install integrations (\`@astrojs/solid-js\`, \`@astrojs/cloudflare\`).
    - **File Migration:** Based on the user's provided project structure, intelligently map old files to new locations and use \`fs-extra\` to copy them.
    - **Code Conversion (Placeholders):** The script should NOT attempt a full code conversion. Instead, for each file, it should copy the original content and then insert **TODO comments** indicating what needs to be manually changed. For example, in a React component, add \`// TODO: Convert React hooks (useState, useEffect) to SolidJS signals (createSignal, createEffect).\`. For an Express route, create a new Astro API route file with boilerplate and add a comment \`// TODO: Port the business logic from the original Express route file here.\`.
    - **Configuration:** Generate the \`astro.config.mjs\` and \`wrangler.toml\` files with the correct configurations, using the \`inquirer\` input to populate values.
    - **Logging:** Use \`chalk\` to provide clear, step-by-step feedback in the console.

3.  **Final Output:**
    - Conclude by printing clear "Next Steps" for the user, emphasizing the manual code conversion work that remains.

**User's Project Structure (for context):**
\`\`\`text
${projectStructure}
\`\`\`

Now, generate the complete Node.js script based on these requirements and the provided structure. Start the response directly with the script code block. Do not add any conversational preamble.`;

    const prompt = `Generate the migration script for this project structure:\n\n${projectStructure}`;

    return callGeminiStream(prompt, systemInstruction);
};
