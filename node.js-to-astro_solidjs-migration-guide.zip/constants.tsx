import { Feature, ArchitecturalLayer } from './types';
import type { FeatureInfo } from './types';

export const FEATURES: FeatureInfo[] = [
    { id: Feature.PROJECT_STRUCTURE, label: 'Project Structure Analysis', description: 'Get a migration plan based on your project files & deploy to Cloudflare.', icon: '[ > ]' },
    { id: Feature.API_ENDPOINTS, label: 'API Endpoints', description: 'Learn how to create serverless API routes.', icon: '[ > ]' },
    { id: Feature.DATABASE_ACCESS, label: 'Database Access', description: 'Connect to and query your database.', icon: '[ > ]' },
    { id: Feature.AUTHENTICATION, label: 'Authentication', description: 'Implement user auth strategies.', icon: '[ > ]' },
    { id: Feature.MIDDLEWARE, label: 'Middleware', description: 'Handle requests with middleware functions.', icon: '[ > ]' },
    { id: Feature.SSR_PAGES, label: 'SSR Pages & Components', description: 'Build dynamic pages and interactive UI.', icon: '[ > ]' },
    { id: Feature.STATIC_FILES, label: 'Serving Static Files', description: 'Manage and serve static assets.', icon: '[ > ]' },
];

export const FEATURE_MAP: Map<Feature, FeatureInfo> = new Map(
  FEATURES.map(feature => [feature.id, feature])
);

export const ONBOARDING_QUESTION_DATA: {
    layer: ArchitecturalLayer;
    description: string;
    icon: string;
}[] = [
    { layer: ArchitecturalLayer.BACKEND_DATA, description: "APIs, database connections, server-side logic.", icon: '[ DB ]' },
    { layer: ArchitecturalLayer.FRONTEND_UI, description: "Interactive components, static files, page rendering.", icon: '[ UI ]' },
    { layer: ArchitecturalLayer.AUTH_SECURITY, description: "User login, protected routes, and security.", icon: '[ PW ]' },
    { layer: ArchitecturalLayer.REQUEST_HANDLING, description: "Middleware, server-rendering, and request lifecycle.", icon: '[ <> ]' }
];

export const LAYER_TO_FEATURE_MAP: Record<ArchitecturalLayer, Feature[]> = {
    [ArchitecturalLayer.BACKEND_DATA]: [Feature.API_ENDPOINTS, Feature.DATABASE_ACCESS],
    [ArchitecturalLayer.FRONTEND_UI]: [Feature.SSR_PAGES, Feature.STATIC_FILES],
    [ArchitecturalLayer.AUTH_SECURITY]: [Feature.AUTHENTICATION],
    [ArchitecturalLayer.REQUEST_HANDLING]: [Feature.MIDDLEWARE, Feature.SSR_PAGES],
};