
import React from 'react';
import { Feature, ArchitecturalLayer } from './types';

const ProjectStructureIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 7.5L7.5 3m0 0L12 7.5M7.5 3v13.5m13.5 0L16.5 21m0 0L12 16.5m4.5 4.5V7.5" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5V12a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 12v4.5" />
    </svg>
);


const ServerIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
    </svg>
);

const DatabaseIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4M4 7s-4 4-4 4m16 0s4-4 4-4M12 11a4 4 0 110-8 4 4 0 010 8z" />
    </svg>
);

const LockIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
    </svg>
);

const FileIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
    </svg>
);

const DocumentIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
    </svg>
);

const MiddlewareIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);


export interface FeatureInfo {
    id: Feature;
    label: string;
    description: string;
    icon: React.ReactNode;
}

export const FEATURES: FeatureInfo[] = [
    { id: Feature.PROJECT_STRUCTURE, label: 'Project Structure Analysis', description: 'Get a migration plan based on your project files & deploy to Cloudflare.', icon: <ProjectStructureIcon /> },
    { id: Feature.API_ENDPOINTS, label: 'API Endpoints', description: 'Learn how to create serverless API routes.', icon: <ServerIcon /> },
    { id: Feature.DATABASE_ACCESS, label: 'Database Access', description: 'Connect to and query your database.', icon: <DatabaseIcon /> },
    { id: Feature.AUTHENTICATION, label: 'Authentication', description: 'Implement user auth strategies.', icon: <LockIcon /> },
    { id: Feature.MIDDLEWARE, label: 'Middleware', description: 'Handle requests with middleware functions.', icon: <MiddlewareIcon /> },
    { id: Feature.SSR_PAGES, label: 'SSR Pages & Components', description: 'Build dynamic pages and interactive UI components.', icon: <DocumentIcon /> },
    { id: Feature.STATIC_FILES, label: 'Serving Static Files', description: 'Manage and serve static assets.', icon: <FileIcon /> },
];

export const FEATURE_MAP: Map<Feature, FeatureInfo> = new Map(
  FEATURES.map(feature => [feature.id, feature])
);

export const ONBOARDING_QUESTION_DATA: {
    layer: ArchitecturalLayer;
    description: string;
    icon: React.ReactNode;
}[] = [
    { layer: ArchitecturalLayer.BACKEND_DATA, description: "APIs, database connections, server-side logic.", icon: <DatabaseIcon /> },
    { layer: ArchitecturalLayer.FRONTEND_UI, description: "Interactive components, static files, page rendering.", icon: <DocumentIcon /> },
    { layer: ArchitecturalLayer.AUTH_SECURITY, description: "User login, protected routes, and security.", icon: <LockIcon /> },
    { layer: ArchitecturalLayer.REQUEST_HANDLING, description: "Middleware, server-rendering, and request lifecycle.", icon: <MiddlewareIcon /> }
];

export const LAYER_TO_FEATURE_MAP: Record<ArchitecturalLayer, Feature[]> = {
    [ArchitecturalLayer.BACKEND_DATA]: [Feature.API_ENDPOINTS, Feature.DATABASE_ACCESS],
    [ArchitecturalLayer.FRONTEND_UI]: [Feature.SSR_PAGES, Feature.STATIC_FILES],
    [ArchitecturalLayer.AUTH_SECURITY]: [Feature.AUTHENTICATION],
    [ArchitecturalLayer.REQUEST_HANDLING]: [Feature.MIDDLEWARE, Feature.SSR_PAGES],
};
