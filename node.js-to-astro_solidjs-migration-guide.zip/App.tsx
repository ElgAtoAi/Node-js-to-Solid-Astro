import React, { useState, useCallback, useEffect } from 'react';
import { Feature } from './types';
import SiteHeader from './components/SiteHeader';
import Footer from './components/Footer';
import FeatureDisplay from './components/FeatureDisplay';
import GuideDisplay from './components/GuideDisplay';
import Loader from './components/Loader';
import ErrorMessage from './components/ErrorMessage';
import ProjectStructureAnalyzer from './components/ProjectStructureAnalyzer';
import { generateMigrationGuide, generateProjectMigrationPlan, generateMigrationScript } from './services/geminiService';

type ContentState = 'idle' | 'loading' | 'guide' | 'analyzer' | 'error';

const App: React.FC = () => {
    const [contentState, setContentState] = useState<ContentState>('idle');
    
    const [guide, setGuide] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [currentFeature, setCurrentFeature] = useState<Feature | null>(null);
    const [projectStructure, setProjectStructure] = useState<string | null>(null);
    const [script, setScript] = useState<string | null>(null);
    const [isGeneratingScript, setIsGeneratingScript] = useState(false);

    useEffect(() => {
        // Add loaded class to body to fade in content
        document.body.classList.add('loaded');
    }, []);

    const resetState = useCallback(() => {
        setContentState('idle');
        setGuide(null);
        setError(null);
        setCurrentFeature(null);
        setProjectStructure(null);
        setScript(null);
        setIsGeneratingScript(false);
        window.scrollTo(0, 0);
    }, []);

    const handleSelectFeature = useCallback(async (feature: Feature) => {
        window.scrollTo(0, 0);
        if (feature === Feature.PROJECT_STRUCTURE) {
            setContentState('analyzer');
            setCurrentFeature(feature);
        } else {
            setContentState('loading');
            setGuide(null);
            setError(null);
            setCurrentFeature(feature);
            try {
                const result = await generateMigrationGuide(feature);
                setGuide(result);
                setContentState('guide');
            } catch (e: any) {
                setError(e.message || 'An unexpected error occurred.');
                setContentState('error');
            }
        }
    }, []);
    
    const handleAnalyzeProject = useCallback(async (structure: string) => {
        window.scrollTo(0, 0);
        setContentState('guide'); // Go to guide view immediately for streaming
        setCurrentFeature(Feature.PROJECT_STRUCTURE);
        setGuide('');
        setScript(null);
        setError(null);
        setProjectStructure(structure);

        try {
            const stream = generateProjectMigrationPlan(structure);
            for await (const chunk of await stream) {
                setGuide(prev => (prev ?? '') + chunk.text);
            }
        } catch (e: any) {
            setError(e.message || 'An unexpected error occurred.');
            setContentState('error');
        }
    }, []);

    const handleGenerateScript = useCallback(async () => {
        if (!projectStructure) return;
        setIsGeneratingScript(true);
        setScript('');
        setError(null);
        try {
            const stream = generateMigrationScript(projectStructure);
            for await (const chunk of await stream) {
                let cleanedChunk = chunk.text.replace(/^```(javascript|js|node)?\n/i, '');
                cleanedChunk = cleanedChunk.replace(/```$/, '');
                setScript(prev => (prev ?? '') + cleanedChunk);
            }
        } catch (e: any) {
            setError(`Failed to generate script: ${e.message || 'An unexpected error occurred.'}`);
        } finally {
            setIsGeneratingScript(false);
        }
    }, [projectStructure]);

    const renderContent = () => {
        if (contentState === 'idle') {
            return <FeatureDisplay onFeatureSelect={handleSelectFeature} />;
        }
        
        return (
            <div className="content-view">
                <button onClick={resetState} className="back-button">
                    &larr; Back to selection
                </button>
                {contentState === 'loading' && <Loader message="Generating your guide..." />}
                {contentState === 'analyzer' && <ProjectStructureAnalyzer onAnalyze={handleAnalyzeProject} />}
                {contentState === 'guide' && guide !== null && currentFeature && (
                    <GuideDisplay 
                        content={guide} 
                        feature={currentFeature} 
                        onGenerateScript={handleGenerateScript}
                        script={script}
                        isGeneratingScript={isGeneratingScript}
                    />
                )}
                {contentState === 'error' && error && <ErrorMessage message={error} />}
            </div>
        );
    };
    
    return (
        <>
            <SiteHeader onLogoClick={resetState} />
            <main id="main-content" className="container">
                {renderContent()}
            </main>
            <Footer />
        </>
    );
};

export default App;