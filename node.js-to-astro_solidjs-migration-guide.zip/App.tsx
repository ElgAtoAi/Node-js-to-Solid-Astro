
import React, { useState, useCallback } from 'react';
import { Feature } from './types';
import Header from './components/Header';
import GuideDisplay from './components/GuideDisplay';
import Loader from './components/Loader';
import ErrorMessage from './components/ErrorMessage';
import ProjectStructureAnalyzer from './components/ProjectStructureAnalyzer';
import IntroAnimation from './components/IntroAnimation';
import OnboardingWizard from './components/OnboardingWizard';
import { generateMigrationGuide, generateProjectMigrationPlan, generateMigrationScript } from './services/geminiService';

type AppState = 'intro' | 'welcome' | 'analyzer' | 'wizard' | 'loading' | 'guide' | 'error';

const App: React.FC = () => {
    const [appState, setAppState] = useState<AppState>('intro');
    const [guide, setGuide] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [currentFeature, setCurrentFeature] = useState<Feature | null>(null);
    const [projectStructure, setProjectStructure] = useState<string | null>(null);
    const [script, setScript] = useState<string | null>(null);
    const [isGeneratingScript, setIsGeneratingScript] = useState(false);


    const handleAnimationComplete = useCallback(() => {
        setAppState('welcome');
    }, []);

    const resetState = useCallback(() => {
        setGuide(null);
        setError(null);
        setCurrentFeature(null);
        setProjectStructure(null);
        setScript(null);
        setIsGeneratingScript(false);
        setAppState('welcome');
    }, []);

    const handleSelectFeature = useCallback(async (feature: Feature) => {
        setAppState('loading');
        setGuide(null);
        setError(null);
        setCurrentFeature(feature);
        try {
            const result = await generateMigrationGuide(feature);
            setGuide(result);
            setAppState('guide');
        } catch (e: any) {
            setError(e.message || 'An unexpected error occurred.');
            setAppState('error');
        }
    }, []);

    const handleAnalyzeProject = useCallback(async (structure: string) => {
        setAppState('guide'); // Go to guide view immediately for streaming
        setCurrentFeature(Feature.PROJECT_STRUCTURE);
        setGuide(''); // Start with an empty string for streaming
        setScript(null);
        setError(null);
        setProjectStructure(structure);

        try {
            const stream = generateProjectMigrationPlan(structure);
            for await (const chunk of await stream) {
                setGuide(prev => (prev ?? '') + chunk.text);
            }
        } catch (e: any) {
            setError(e.message || 'An unexpected error occurred.');
            setAppState('error');
        }
    }, []);
    
    const handleGenerateScript = useCallback(async () => {
        if (!projectStructure) return;

        setIsGeneratingScript(true);
        setScript(''); // Start with an empty string for streaming
        setError(null);

        try {
            const stream = generateMigrationScript(projectStructure);
            for await (const chunk of await stream) {
                // The script is often returned inside a markdown block, so we clean it up.
                let cleanedChunk = chunk.text.replace(/^```(javascript|js|node)?\n/i, '');
                cleanedChunk = cleanedChunk.replace(/```$/, '');
                setScript(prev => (prev ?? '') + cleanedChunk);
            }
        } catch (e: any) {
            setError(`Failed to generate script: ${e.message || 'An unexpected error occurred.'}`);
        } finally {
            setIsGeneratingScript(false);
        }
    }, [projectStructure]);


    const WelcomeScreen = () => (
        <div className="text-center p-8 animate-fade-in">
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">How can I help you today?</h2>
            <p className="text-gray-400 max-w-2xl mx-auto mb-10">
                Choose an option below to get started. You can either get a full migration plan by analyzing your project's structure, or get specific guidance on a particular feature through a quick questionnaire.
            </p>
            <div className="flex flex-col md:flex-row justify-center gap-6">
                <button
                    onClick={() => setAppState('analyzer')}
                    className="group bg-gray-800 p-8 rounded-lg border border-gray-700 hover:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all duration-300 transform hover:-translate-y-1 flex-1 text-left"
                >
                    <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">Analyze Project Structure</h3>
                    <p className="text-gray-400 mt-2">Generate a full migration plan and an optional automation script based on your project's file structure.</p>
                </button>
                <button
                     onClick={() => setAppState('wizard')}
                    className="group bg-gray-800 p-8 rounded-lg border border-gray-700 hover:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all duration-300 transform hover:-translate-y-1 flex-1 text-left"
                >
                    <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">Find Specific Guidance</h3>
                    <p className="text-gray-400 mt-2">Answer a couple of questions to get a detailed guide for a specific technical challenge.</p>
                </button>
            </div>
        </div>
    );

    const renderContent = () => {
        const stateToComponent: Record<AppState, React.ReactNode> = {
            intro: <IntroAnimation onAnimationComplete={handleAnimationComplete} />,
            welcome: <WelcomeScreen />,
            wizard: <OnboardingWizard onFeatureSelect={handleSelectFeature} onBack={resetState} />,
            analyzer: <ProjectStructureAnalyzer onAnalyze={handleAnalyzeProject} />,
            loading: <Loader message="Generating your guide..." />,
            guide: guide !== null && currentFeature ? 
                <GuideDisplay 
                    content={guide} 
                    feature={currentFeature} 
                    onGenerateScript={handleGenerateScript}
                    script={script}
                    isGeneratingScript={isGeneratingScript}
                /> : <Loader message="Preparing your guide..." />,
            error: error ? <ErrorMessage message={error} /> : <ErrorMessage message="An unknown error occurred." />,
        };

        const content = stateToComponent[appState];
        
        if (appState === 'intro') {
            return content;
        }

        return (
            <div className="min-h-screen bg-gray-900 text-gray-200 animate-fade-in">
                <Header />
                <main className="container mx-auto px-4 py-8 max-w-5xl">
                    {appState === 'guide' || appState === 'analyzer' || appState === 'error' || appState === 'wizard' ? (
                        <div>
                            <button
                                onClick={resetState}
                                className="mb-8 flex items-center text-sm font-semibold text-cyan-400 hover:text-cyan-300 transition-colors group"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 transform group-hover:-translate-x-1 transition-transform" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                                </svg>
                                Start Over
                            </button>
                            {content}
                        </div>
                    ) : (
                        content
                    )}
                </main>
                <footer className="text-center py-4 text-sm text-gray-500 font-mono">
                    <p>// developed by eLgAtoAi - powered by Gemini</p>
                </footer>
            </div>
        );
    };

    return renderContent();
};

export default App;
